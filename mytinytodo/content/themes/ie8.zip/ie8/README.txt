This is a theme for old browsers without full support of SVG and Flexbox like Internet Explorer 8, Opera 12

To enable it just change the template option in config.php like below:
$config['template'] = 'ie8';

Or you can copy file index_ie8.php to the root directory and use it as start page.
